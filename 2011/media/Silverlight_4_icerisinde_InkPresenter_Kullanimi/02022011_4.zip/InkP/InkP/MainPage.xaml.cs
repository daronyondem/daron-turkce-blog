﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.IO;

namespace InkP
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            InkPresent.MouseLeftButtonDown += new MouseButtonEventHandler(InkPresent_MouseLeftButtonDown);
            InkPresent.MouseMove += new MouseEventHandler(InkPresent_MouseMove);
            InkPresent.MouseLeftButtonUp += new MouseButtonEventHandler(InkPresent_MouseLeftButtonUp);
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
            this.btnKalinKirmizi.Click += new RoutedEventHandler(btnKalinKirmizi_Click);
            this.btnNormal.Click += new RoutedEventHandler(btnNormal_Click);
        }
        
        void btnKalinKirmizi_Click(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
            Att.Color = Colors.Red;
            Att.Width = 10;
        }

        void btnNormal_Click(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
            Att.Color = Colors.Black;
            Att.Width = 3;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
        }
                
        System.Windows.Ink.Stroke newStroke;
        System.Windows.Ink.DrawingAttributes Att;

        void InkPresent_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            InkPresent.CaptureMouse();
            newStroke = new System.Windows.Ink.Stroke();
            newStroke.DrawingAttributes = Att;
            newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(InkPresent));
            InkPresent.Strokes.Add(newStroke);
        }

        void InkPresent_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            newStroke = null;
            InkPresent.ReleaseMouseCapture();
        }

        void InkPresent_MouseMove(object sender, MouseEventArgs e)
        {
            if (newStroke != null)
            {
                newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(InkPresent));
            }
        }
    }
}
