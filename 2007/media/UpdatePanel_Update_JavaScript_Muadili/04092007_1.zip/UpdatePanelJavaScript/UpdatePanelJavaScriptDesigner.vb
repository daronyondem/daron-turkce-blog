Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports AjaxControlToolkit.Design

Namespace UpdatePanelJavaScript

    Class UpdatePanelJavaScriptDesigner 
        Inherits ExtenderControlBaseDesigner(Of UpdatePanelJavaScriptExtender) 

    End Class

End Namespace
