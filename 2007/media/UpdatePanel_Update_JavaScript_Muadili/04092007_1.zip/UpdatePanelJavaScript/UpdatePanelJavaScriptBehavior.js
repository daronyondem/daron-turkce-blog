/**
 * @author Daron Y�ndem 
 * @web http://daron.yondem.com
 */
Type.registerNamespace('UpdatePanelJavaScript');
UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior = function(element) {
    UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.initializeBase(this, [element]);
    //ClientCommand �zelli�imiz i�in i� bir de�i�ken tan�mlad�k.
    this._ClientCommandValue = null;
}
UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.prototype = {
    initialize : function() {
        UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.callBaseMethod(this, 'initialize');
    },
    dispose : function() {
        UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.callBaseMethod(this, 'dispose');
    },
    //ClientCommand �zelli�i i�in Set ve Get JavaScript metodlar�n� tan�mlad�k.
     get_ClientCommand : function() {
        return this._ClientCommandValue;
    },
    set_ClientCommand : function(value) {
        this._ClientCommandValue = value;
    }
}
UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.registerClass('UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior', AjaxControlToolkit.BehaviorBase);
//JavaScript fonksiyonu �al��t�r�ld���nda buras� �al��acak.
//Buradaki Update JavaScript metodu parametre olarak
//parametremizi ve gizli TextBox'�n ID sini al�yor.
UpdatePanelJavaScript.Update = function(HiddenBoxID, parameter) {
  //Gizli TextBox kontrol�n� buluyoruz.
	var HiddenBox =$get(HiddenBoxID);
  //Parametre yoksa rastgele bir say� d�nd�relim.
	if (typeof(parameter)=="undefined")
	{
		parameter = "RANDOMPARAM" + Math.random();
	};
	//E�er bir �nceki aktar�lan parametre ile 
	//�imdiki ayn� ise parametremizin sonuna RastGele bir say� ekliyoruz.
	if (HiddenBox.value == parameter)
	{
		parameter = parameter + "RANDOMPARAM" + Math.random();
	};
	//Parametremizi TextBox'�n i�ine koyuyoruz.
	HiddenBox.value = parameter;
	//TextBox'�n onchange �zelli�inde JavaScript kodunu al�yoruz ve temizliyoruz.
	var MyCommand = String(HiddenBox.onchange).replace('function anonymous()\n{\n','');
	MyCommand = MyCommand.replace('\n}','');
	MyCommand = MyCommand.replace('function onchange(event) {\njavascript:\n','');
	//onchange durumundaki JavaScript kodunu �al��t�r�yoruz.
	eval(MyCommand);
};

