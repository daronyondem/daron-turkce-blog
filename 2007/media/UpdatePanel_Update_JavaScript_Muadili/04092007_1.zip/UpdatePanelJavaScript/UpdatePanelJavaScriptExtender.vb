Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports AjaxControlToolkit

#Region "Assembly Resource Attribute"
<Assembly: System.Web.UI.WebResource("UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.js", "text/javascript")> 
#End Region

Namespace UpdatePanelJavaScript

    <Description("Creates JavaScript interface simulating UpdatePanel.Update()")> _
    <Designer(GetType(UpdatePanelJavaScriptDesigner))> _
    <ClientScriptResource("UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior", "UpdatePanelJavaScript.UpdatePanelJavaScriptBehavior.js")> _
    <TargetControlType(GetType(UpdatePanel))> _
    Public Class UpdatePanelJavaScriptExtender
        Inherits ExtenderControlBase

        'Durumlar� ile beraber UpdatePanel i�erisine ekleyece�imiz
        'TextBox'� yarat�yoruz.
        WithEvents MyTextBox As New System.Web.UI.WebControls.TextBox
        'Extender kontrol�m�ze ait Update durumunu tan�ml�yoruz.
        Public Event Update(ByVal Sender As Object, ByVal E As EventArgs, ByVal parameter As String)

        'ClientCommand �zelli�ine ait Get ve Set metodlar�.
        <ExtenderControlProperty()> _
        <DefaultValue("Update")> _
        Public Property ClientCommand() As String
            Get
                Return GetPropertyValue("ClientCommand", "")
            End Get
            Set(ByVal value As String)
                SetPropertyValue("ClientCommand", value)
            End Set
        End Property

        'Extender Render edildi�inde ilk �al��t�r�lan kodlar.
        Private Sub UpdatePanelJavaScriptExtender_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
            'TextBox AutoPostBack olsun.
            MyTextBox.AutoPostBack = True
            'TextBox sayfada g�r�nmez olsun
            MyTextBox.Style.Add("visibility", "hidden")
            MyTextBox.Style.Add("display", "none")
            'Hedef UpdatePanel'i bulal�m.
            Dim TargetPanel As System.Web.UI.UpdatePanel = Me.TargetControl
            'TextBox'� ekleyelim.
            TargetPanel.ContentTemplateContainer.Controls.Add(MyTextBox)
            'OnClientCommand �zelli�ine verilen JavaScript fonksiyonunu yaratal�m.
            Dim script As New System.Web.UI.HtmlControls.HtmlGenericControl("script")
            script.Attributes.Add("type", "text/javascript")
            script.Attributes.Add("language", "javascript")
            Dim builder As New System.Text.StringBuilder
            '    builder.AppendLine("<script language='javascript' type='text/javascript'>")
            builder.Append("function ")
            builder.Append(Me.ClientCommand)
            builder.AppendLine("(parameter) {")
            builder.Append("UpdatePanelJavaScript.Update('")
            builder.Append(MyTextBox.ClientID)
            builder.AppendLine("', parameter);")
            builder.AppendLine("};")
            '    builder.AppendLine("</script>")
            script.InnerHtml = builder.ToString
            'JavaScript fonksiyonumuzu Extender'a ekleyelim.
            Me.Controls.Add(script)
        End Sub

        Sub Control_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyTextBox.TextChanged
            Dim SenderControl As System.Web.UI.WebControls.TextBox = sender
            If SenderControl.Text.IndexOf("RANDOMPARAM") <> -1 Then
                If SenderControl.Text.IndexOf("RANDOMPARAM") = 0 Then
                    RaiseEvent Update(Me, e, "")
                Else
                    RaiseEvent Update(Me, e, SenderControl.Text.Substring(0, SenderControl.Text.IndexOf("RANDOMPARAM")))
                End If
            Else
                RaiseEvent Update(Me, e, SenderControl.Text)
            End If
        End Sub
    End Class

End Namespace
