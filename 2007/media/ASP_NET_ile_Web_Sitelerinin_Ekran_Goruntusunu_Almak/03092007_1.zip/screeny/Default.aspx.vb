
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim NewTh As New Threading.Thread(AddressOf DoIT)
        NewTh.SetApartmentState(Threading.ApartmentState.STA)
        NewTh.Start()
        While NewTh.ThreadState = Threading.ThreadState.Running
        End While
        Image1.ImageUrl = TextBox1.Text.Replace(".", "_") & ".jpg"
    End Sub

    Sub DoIT()
        Try
            Dim thumb As New GetSiteThumbnail.GetImage("http://" & TextBox1.Text, 1024, 768, 320, 240)
            Dim x As System.Drawing.Bitmap = thumb.GetBitmap()
            x.Save(Server.MapPath(".") & "\" & TextBox1.Text.Replace(".", "_") & ".jpg")
        Catch ex As Exception
            Dim y As System.IO.StreamWriter = System.IO.File.CreateText("C:\Inetpub\wwwroot\screeny\error.txt")
            y.WriteLine(ex.Message & vbCrLf & ex.Source)
            y.Flush()
            y.Close()
        Finally
        End Try
    End Sub
End Class
