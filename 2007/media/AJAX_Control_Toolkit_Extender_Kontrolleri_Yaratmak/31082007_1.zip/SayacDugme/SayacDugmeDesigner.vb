Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports AjaxControlToolkit.Design

Namespace SayacDugme

    Class SayacDugmeDesigner 
        Inherits ExtenderControlBaseDesigner(Of SayacDugmeExtender) 

    End Class

End Namespace
