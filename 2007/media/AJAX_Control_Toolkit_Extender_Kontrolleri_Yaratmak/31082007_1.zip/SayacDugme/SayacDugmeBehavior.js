Type.registerNamespace('SayacDugme');

SayacDugme.SayacDugmeBehavior = function(element) {
    SayacDugme.SayacDugmeBehavior.initializeBase(this, [element]);
    this._TargetButtonIDValue = null;
    this._MetinValue = null;
};

SayacDugme.SayacDugmeBehavior.prototype = {
	  _onkeyup : function() {
		  var harf_sayisi = this.get_element().value.length;
		  var dugme = $get(this._TargetButtonIDValue);
		  dugme.value = this._MetinValue + '(' + harf_sayisi + ')';
	  },
    initialize : function() {
        SayacDugme.SayacDugmeBehavior.callBaseMethod(this, 'initialize');
        $addHandler(this.get_element(), 'keyup',
        Function.createDelegate(this, this._onkeyup));
		this._onkeyup();
    }, 
    dispose : function() {
        SayacDugme.SayacDugmeBehavior.callBaseMethod(this, 'dispose');
    },

    get_TargetButtonID : function() {
        return this._TargetButtonIDValue;
    },
    set_TargetButtonID : function(value) {
        this._TargetButtonIDValue = value;
    },
    get_Metin : function() {
        return this._MetinValue;
    },
    set_Metin : function(value) {
        this._MetinValue = value;
    }
};

SayacDugme.SayacDugmeBehavior.registerClass('SayacDugme.SayacDugmeBehavior', AjaxControlToolkit.BehaviorBase);