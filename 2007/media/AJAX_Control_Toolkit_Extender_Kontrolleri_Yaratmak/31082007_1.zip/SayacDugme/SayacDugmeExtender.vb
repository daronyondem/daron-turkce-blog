Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports AjaxControlToolkit

#Region "Assembly Resource Attribute"
<Assembly: System.Web.UI.WebResource("SayacDugme.SayacDugmeBehavior.js", "text/javascript")> 
#End Region

Namespace SayacDugme

    <Designer(GetType(SayacDugmeDesigner))> _
    <ClientScriptResource("SayacDugme.SayacDugmeBehavior", "SayacDugme.SayacDugmeBehavior.js")> _
    <TargetControlType(GetType(TextBox))> _
    Public Class SayacDugmeExtender
        Inherits ExtenderControlBase

        <ExtenderControlProperty()> _
        <DefaultValue("")> _
        <IDReferenceProperty(GetType(Button))> _
        Public Property TargetButtonID() As String
            Get
                Return GetPropertyValue("TargetButtonID", "")
            End Get
            Set(ByVal value As String)
                SetPropertyValue("TargetButtonID", value)
            End Set
        End Property

        <ExtenderControlProperty()> _
        <DefaultValue("")> _
        Public Property Metin() As String
            Get
                Return GetPropertyValue("Metin", "")
            End Get
            Set(ByVal value As String)
                SetPropertyValue("Metin", value)
            End Set
        End Property

    End Class

End Namespace