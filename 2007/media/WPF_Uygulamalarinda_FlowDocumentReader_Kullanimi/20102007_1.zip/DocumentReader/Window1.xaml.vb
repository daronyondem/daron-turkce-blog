﻿Imports System
Imports System.IO
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Navigation

Partial Public Class Window1
	Public Sub New()
		MyBase.New()

		Me.InitializeComponent()

		' Insert code required on object creation below this point.
	End Sub

    Private Sub DokAcTiklandi(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Dim flowDoc As FlowDocumentReader = CType(Me.FindName("flowDoc"), FlowDocumentReader)
        Dim yeniDoc As Documents.FlowDocument = Nothing
        Dim Dialog As New Microsoft.Win32.OpenFileDialog
        Dialog.Filter = "FlowDocument Dosyaları (*.xaml)|*.xaml"
        If Dialog.ShowDialog.Value Then
            Dim xamlDosya As FileStream = CType(Dialog.OpenFile, FileStream)
            Try
                yeniDoc = CType(Markup.XamlReader.Load(xamlDosya), Documents.FlowDocument)
                flowDoc.Document = yeniDoc
            Catch ex As Exception
                System.Windows.MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
End Class
