' Interaction logic for Window2.xaml
Partial Public Class Window2
    Inherits System.Windows.Window

    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub Button1_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        MessageBox.Show(Application.Current.Properties.Item("Sahip").adi)
        MessageBox.Show(Application.Current.Properties.Item("Sahip").soyadi)
    End Sub

    Private Sub Window2_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Me.Closing
        Application.Current.Shutdown()
    End Sub
End Class
