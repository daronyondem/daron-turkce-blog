' Interaction logic for Window1.xaml
Partial Public Class Window1
    Inherits System.Windows.Window

    Public Sub New()
        InitializeComponent()
    End Sub

    Public Class Adam
        Dim _Adi As String
        Dim _Soyadi As String

        Property Adi() As String
            Get
                Return _Adi
            End Get
            Set(ByVal value As String)
                _Adi = value
            End Set
        End Property

        Property Soyadi() As String
            Get
                Return _Soyadi
            End Get
            Set(ByVal value As String)
                _Soyadi = value
            End Set
        End Property

        Sub New()

        End Sub

        Sub New(ByVal Adi As String, ByVal Soyadi As String)
            Me.Adi = Adi
            Me.Soyadi = Soyadi
        End Sub

    End Class

    Private Sub Kaydet_Click(ByVal sender As Object, ByVal e As System.Windows.RoutedEventArgs) Handles Button1.Click
        Dim YeniAdam As New Adam(TextBox1.Text, TextBox2.Text)
        If Application.Current.Properties.Contains("Sahip") = False Then
            Application.Current.Properties.Add("Sahip", YeniAdam)
        Else
            Application.Current.Properties.Item("Sahip") = YeniAdam
        End If
    End Sub
End Class
