' Interaction logic for App.xaml
Partial Public Class App
    Inherits System.Windows.Application

    Private Sub App_Startup(ByVal sender As Object, ByVal e As System.Windows.StartupEventArgs) Handles Me.Startup
        Dim x As New Window2
        x.Show()
    End Sub
End Class
