﻿
Partial Class Default4
    Inherits System.Web.UI.Page

    Public Class Urun
        Private PAdi As String
        Private PStok As Integer
        Property Adi() As String
            Get
                Return PAdi
            End Get
            Set(ByVal value As String)
                PAdi = value
            End Set
        End Property

        Property Stok() As Integer
            Get
                Return PStok
            End Get
            Set(ByVal value As Integer)
                PStok = value
            End Set
        End Property

        Sub New()

        End Sub

        Sub New(ByVal adi As String, ByVal stok As Integer)
            Me.Adi = adi
            Me.Stok = stok

        End Sub


    End Class

    <Services.WebMethod()> _
    Public Shared Function Urunler(ByVal KatID As Integer) As System.Collections.Generic.List(Of Urun)
        Dim liste As New System.Collections.Generic.List(Of Urun)
        For x As Integer = 0 To 10
            liste.Add(New Urun("Urun adi" & x, (Rnd() * 1000) + 500))
        Next
        Return liste
    End Function
End Class
