﻿
Partial Class Default2
    Inherits System.Web.UI.Page

    '[System.Web.Services.WebMethod()]
    <Services.WebMethod()> _
    Public Shared Function Toplama(ByVal x As Integer, _
        ByVal y As Integer) As Integer
        Return x + y
    End Function
End Class
