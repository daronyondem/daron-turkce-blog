﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default6 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = DateTime.Now.ToLongTimeString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        label1.Text = (int.Parse(label1.Text) + 1).ToString();
        UpdateHistory1.AddEntry(label1.Text);
    }
    protected void UpdateHistory1_Navigate(object sender, nStuff.UpdateControls.HistoryEventArgs e)
    {
        if (!string.IsNullOrEmpty(e.EntryName))
        {
            label1.Text = e.EntryName;
        }
        else
        {
            label1.Text = "0";
        }
        UpdatePanel1.Update();
    }
}
