﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.Text = Date.Now.ToLongTimeString

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label1.Text = Date.Now.ToLongTimeString
        Label2.Text = Date.Now.ToLongTimeString
        UpdatePanel1.Update()

    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        System.Threading.Thread.Sleep(5000)

        Label2.Text = Date.Now.ToLongTimeString
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
  
End Class
