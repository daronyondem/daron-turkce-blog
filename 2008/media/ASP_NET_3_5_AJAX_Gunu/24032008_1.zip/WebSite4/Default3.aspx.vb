﻿
Partial Class Default3
    Inherits System.Web.UI.Page

    Protected Sub button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button1.Click
        etiket.Text = CInt(text1.Text) + TextBox1.Text

    End Sub
End Class
