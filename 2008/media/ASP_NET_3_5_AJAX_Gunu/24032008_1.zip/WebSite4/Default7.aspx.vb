﻿
Partial Class Default7
    Inherits System.Web.UI.Page

    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label1.Text = TextBox1.Text
    End Sub
End Class
