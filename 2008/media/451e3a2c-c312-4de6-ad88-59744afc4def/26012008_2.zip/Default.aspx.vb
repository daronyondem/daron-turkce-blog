﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Class Urun
        Private PAdi As String
        Private PSatis As Integer

        Property Adi() As String
            Get
                Return PAdi
            End Get
            Set(ByVal value As String)
                PAdi = value
            End Set
        End Property

        Property Satis() As Integer
            Get
                Return PSatis
            End Get
            Set(ByVal value As Integer)
                PSatis = value
            End Set
        End Property

        Sub New()

        End Sub

        Sub New(ByVal Adi As String, ByVal Satis As Integer)
            PAdi = Adi
            PSatis = Satis
        End Sub
    End Class

    '[System.Web.Services.WebMethod()]
    <System.Web.Services.WebMethod()> _
    Public Shared Function Urunler() As System.Collections.Generic.List(Of Urun)
        Dim liste As New System.Collections.Generic.List(Of Urun)
        For i As Integer = 0 To 10
            liste.Add(New Urun("UrunAdi_" & i, (Rnd() * 500) + 500))
        Next
        Return liste
    End Function


End Class
