﻿function createSilverlight()
{
	var scene = new UntitledProject2.Page();
	Silverlight.createObjectEx({
		source: "Page.xaml",
		parentElement: document.getElementById("silverlightControlHost"),
		id: "SilverlightControl",
		properties: {
			width: "100%",
			height: "100%",
			version: "1.0"
		},
		events: {
			onLoad: Silverlight.createDelegate(scene, scene.handleLoad),
			onError: function(sender, args) {
				var errorDiv = document.getElementById("errorLocation");
				if (errorDiv != null) {
					var errorText = args.errorType + "- " + args.errorMessage;
							
					if (args.ErrorType == "ParserError") {
						errorText += "<br>File: " + args.xamlFile;
						errorText += ", line " + args.lineNumber;
						errorText += " character " + args.charPosition;
					}
					else if (args.ErrorType == "RuntimeError") {
						errorText += "<br>line " + args.lineNumber;
						errorText += " character " +  args.charPosition;
					}
					errorDiv.innerHTML = errorText;
				}	
			}
		}
	});
}


if (!window.Silverlight) 
	window.Silverlight = {};

Silverlight.createDelegate = function(instance, method) {
	return function() {
		return method.apply(instance, arguments);
	}
}