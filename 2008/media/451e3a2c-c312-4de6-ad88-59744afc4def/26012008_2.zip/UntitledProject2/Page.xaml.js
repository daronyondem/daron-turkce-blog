﻿if (!window.UntitledProject2)
	window.UntitledProject2 = {};

UntitledProject2.Page = function() 
{
}

UntitledProject2.Page.prototype =
{
	handleLoad: function(control, userContext, rootElement) 
	{
}
}
function Oynat(sender)
{
sender.findName("mediaElement")["Source"] = "bear.wmv";
sender.findName("mediaElement").Play();
}
function Durdur(sender)
{
sender.findName("DurdurAnim").Begin();
sender.findName("mediaElement").Stop();
}
function Yukleniyor(sender)
{
sender.findName("Osman")["Text"] = "Yukleniyor..." + (Math.round(sender.BufferingProgress*100)) + "%";
  if(sender.BufferingProgress==1)
  {
  sender.findName("OynatAnim").Begin();
  
  }
}