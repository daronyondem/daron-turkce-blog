﻿if (!window.UntitledProject3)
	window.UntitledProject3 = {};

UntitledProject3.Page = function() 
{
}

UntitledProject3.Page.prototype =
{
	handleLoad: function(control, userContext, rootElement) 
	{
}
}
var BaslangicX;
var BaslangicY;
var BasiliMi = false;

function MouseDown(sender, Args)
{
	BaslangicX = Args.getPosition(null).x;
	BaslangicY = Args.getPosition(null).y;
BasiliMi=true;
	sender.captureMouse();
}

function MouseMove(sender,args)
{
	if(BasiliMi == true)
	{
		var SimdikiX = args.getPosition(null).x;
		var SimdikiY = args.getPosition(null).y;
		sender["Canvas.Left"] += SimdikiX - BaslangicX;
		sender["Canvas.Top"] += SimdikiY - BaslangicY;
		BaslangicX = SimdikiX;
		BaslangicY = SimdikiY;
	}
}
function MouseUp(sender,args)
{
	 BasiliMi = false;
	 sender.releaseMouseCapture();
}