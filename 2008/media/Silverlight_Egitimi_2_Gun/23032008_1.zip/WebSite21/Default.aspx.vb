﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    <Services.WebMethod()> _
    Public Shared Function Carp(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x * y

    End Function

End Class
