﻿Imports System.ServiceModel
Imports System.ServiceModel.Activation
Imports System.ServiceModel.Web

<ServiceContract(Namespace:="")> _
<AspNetCompatibilityRequirements(RequirementsMode:=AspNetCompatibilityRequirementsMode.Allowed)> _
Public Class Service

    Public Class Urun
        Private PAdi As String
        Private PStok As Integer

        Public Property Adi() As String
            Get
                Return PAdi
            End Get
            Set(ByVal value As String)
                PAdi = value
            End Set
        End Property

        Public Property Stok() As Integer
            Get
                Return PStok
            End Get
            Set(ByVal value As Integer)
                PStok = value
            End Set
        End Property

        Sub New()

        End Sub

        Sub New(ByVal adi As String, ByVal stok As Integer)
            Me.Adi = adi
            Me.Stok = stok
        End Sub

    End Class

    <OperationContract()> _
    Public Function Urunler(ByVal x As Integer) As System.Collections.Generic.List(Of Urun)
        Dim liste As New System.Collections.Generic.List(Of Urun)
        For y As Integer = 1 To 10
            liste.Add(New Urun("Adi_" & y, (Rnd() * 1000) + 500))
        Next
        Return liste
    End Function

End Class
