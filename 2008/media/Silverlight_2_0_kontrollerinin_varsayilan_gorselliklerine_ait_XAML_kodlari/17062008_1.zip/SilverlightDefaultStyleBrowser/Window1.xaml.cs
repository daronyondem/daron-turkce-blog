﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SilverlightDefaultStyleBrowser
{
    public partial class Window1 : Window
    {
        // Collection of default styles
        private ObservableCollection<DefaultStyle> _defaultStyles;

        public Window1()
        {
            // Initialize state
            InitializeComponent();
            Title += " - " + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            _defaultStyles = new ObservableCollection<DefaultStyle>();
            DataContext = _defaultStyles;

            // Hook up event handlers
            AddAssembly.Click += new RoutedEventHandler(AddAssembly_Click);
            StyleList.SelectionChanged += new SelectionChangedEventHandler(StyleList_SelectionChanged);
            WebBrowser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(WebBrowser_DocumentCompleted);
            CopyStyle.Click += new RoutedEventHandler(CopyStyleOrTemplate_Click);
            CopyTemplate.Click += new RoutedEventHandler(CopyStyleOrTemplate_Click);

            // Attempt pre-population of Silverlight and SDK control assemblies
            var programFilesX86 = Environment.GetEnvironmentVariable("ProgramFiles(x86)") ?? Environment.GetEnvironmentVariable("ProgramFiles");
            if (null != programFilesX86)
            {
                foreach (var directory in new[] {
                    Path.Combine(programFilesX86, @"Microsoft SDKs\Silverlight\v2.0\Libraries\Client"),
                    Path.Combine(programFilesX86, @"Microsoft Silverlight\2.0.30523.6"),
                })
                {
                    try
                    {
                        foreach (var file in Directory.GetFiles(directory, "*.dll"))
                        {
                            ImportDefaultStyles(file);
                        }
                    }
                    catch (DirectoryNotFoundException)
                    {
                        // Directory not present; skip pre-populate
                    }
                }
            }
        }

        private void ImportDefaultStyles(string fileName)
        {
            Assembly assembly = null;
            try
            {
                // Load assembly, loop through each resource stream
                assembly = Assembly.LoadFile(fileName);
            }
            catch (BadImageFormatException)
            {
                // Invalid assembly file
                return;
            }
            foreach (var resourceName in assembly.GetManifestResourceNames())
            {
                using (var resourceStream = assembly.GetManifestResourceStream(resourceName))
                {
                    // Try to create a ResourceReader for the stream
                    ResourceReader resourceReader = null;
                    try
                    {
                        resourceReader = new ResourceReader(resourceStream);
                    }
                    catch (ArgumentException)
                    {
                        // Not a ResourceReader stream
                        continue;
                    }
                    using (resourceReader)
                    {
                        // Try to get resource data for generic.xaml
                        string resourceType = null;
                        byte[] resourceData = null;
                        try
                        {
                            resourceReader.GetResourceData("generic.xaml", out resourceType, out resourceData);
                        }
                        catch (ArgumentException)
                        {
                            // generic.xaml not present
                            continue;
                        }
                        // If generic.xaml is available, create a reader for the stream
                        if ((0 == string.Compare("ResourceTypeCode.Stream", resourceType, StringComparison.OrdinalIgnoreCase)) &&
                            (4 <= resourceData.Length))
                        {
                            // Note: Ignore first 4 bytes (http://blogs.gotdotnet.com/bclteam/archive/2005/06/07/426325.aspx)
                            using (var genericStream = new MemoryStream(resourceData, 4, resourceData.Length - 4))
                            {
                                using (var genericReader = new StreamReader(genericStream))
                                {
                                    // Add each default style to the collection
                                    var document = XDocument.Load(genericReader);
                                    var resourceDictionaryName = XName.Get("ResourceDictionary", Constants.RootNamespace);
                                    var styleName = XName.Get("Style", Constants.RootNamespace);
                                    foreach (var defaultStyle in document.Elements(resourceDictionaryName).Elements(styleName))
                                    {
                                        _defaultStyles.Add(new DefaultStyle(assembly, defaultStyle));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        void AddAssembly_Click(object sender, RoutedEventArgs e)
        {
            // Display open file dialog to pick assembly file(s)
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                CheckFileExists=true,
                Filter="Assemblies (*.dll)|*.dll|All Files (*)|*",
                Multiselect=true,
            };
            var result = dialog.ShowDialog();
            // If files were selected, read their default styles
            if (result.HasValue && result.Value)
            {
                foreach (var fileName in dialog.FileNames)
                {
                    ImportDefaultStyles(fileName);
                }
            }
        }

        void StyleList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var defaultStyle = StyleList.SelectedItem as DefaultStyle;
            if (null == defaultStyle)
            {
                // No current selection
                WebBrowser.DocumentText = "";
            }
            else
            {
                // IE seems happiest about displaying XML when given (a file) (with the ".xml" extension)
                var tempFileName = Path.GetTempPath() + Path.GetRandomFileName() + ".xml";
                File.WriteAllText(tempFileName, defaultStyle.Style);
                WebBrowser.Url = new Uri(tempFileName);
                // Wait for WebBrowser.DocumentCompleted event to delete the in-use file
            }
        }

        void WebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            // Delete temporary file
            File.Delete(e.Url.AbsolutePath);
        }

        void CopyStyleOrTemplate_Click(object sender, RoutedEventArgs e)
        {
            var defaultStyle = StyleList.SelectedItem as DefaultStyle;
            if (null != defaultStyle)
            {
                // Get style/template to copy
                var text = (CopyStyle == sender) ? defaultStyle.Style : defaultStyle.Template;
                if(!Namespaces.IsChecked.HasValue || !Namespaces.IsChecked.Value)
                {
                    // Remove namespace definitions so clipboard text can be pasted and used as-is
                    text = text.
                        Replace("xmlns=\"" + Constants.RootNamespace + "\"", "").
                        Replace("xmlns:x=\"" + Constants.XNamespace + "\"", "");
                }
                // Copy style/template to clipboard
                System.Windows.Clipboard.SetText(text);
            }
        }
    }

    class DefaultStyle
    {
        public string FullType { get; private set; }
        public string Type { get; private set; }
        public string Style { get; private set; }
        public string Template { get; private set; }

        public DefaultStyle(Assembly assembly, XElement style)
        {
            // Get TargetType
            var targetTypeAttribute = style.Attribute("TargetType");
            Type = (null != targetTypeAttribute) ? targetTypeAttribute.Value : "[UNKNOWN]";

            // Trim off leading namespace (if any) to get friendly type name
            var split = Type.Split(':');
            Type = split[split.Length - 1];
            FullType = assembly.GetName().Name + ":" + Type;

            // Identify ControlTemplate within property setter
            var controlTemplateName = XName.Get("ControlTemplate", Constants.RootNamespace);
            var controlTemplate = style.
                Elements().Where(e => 0 == string.Compare("Template", e.Attribute("Property").Value, StringComparison.OrdinalIgnoreCase)).
                Descendants().Where(e => controlTemplateName == e.Name).FirstOrDefault();

            if (null != controlTemplate)
            {
                // The namespace that's present in Beta 2 for VSM elements causes compile error "Unexpected PROPERTYELEMENT in parse rule ..." when it is defined on an element that uses it
                // Avoid this problem by proactively adding that namespace to the Template
                controlTemplate.Add(new XAttribute(XName.Get("vsm", XNamespace.Xmlns.NamespaceName), "clr-namespace:System.Windows;assembly=System.Windows"));
            }

            // Capture style/template strings (to allow the XML OM to become garbage)
            Style = style.ToString();
            Template = (null != controlTemplate) ? controlTemplate.ToString() : "";
        }
    }

    static class Constants
    {
        // Default XML namespaces for generic.xaml
        public const string RootNamespace = "http://schemas.microsoft.com/winfx/2006/xaml/presentation";
        public const string XNamespace = "http://schemas.microsoft.com/winfx/2006/xaml";
    }
}
