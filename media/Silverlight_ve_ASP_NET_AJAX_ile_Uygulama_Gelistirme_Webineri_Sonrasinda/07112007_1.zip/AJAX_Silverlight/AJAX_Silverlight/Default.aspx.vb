Partial Public Class _Default
    Inherits System.Web.UI.Page

    Public Class Dugme
        Private _Adi As String
        Private _ID As String

        Property Adi() As String
            Get
                Return _Adi
            End Get
            Set(ByVal value As String)
                _Adi = value
            End Set
        End Property

        Property ID() As String
            Get
                Return _ID
            End Get
            Set(ByVal value As String)
                _ID = value
            End Set
        End Property

        Sub New()

        End Sub

        Sub New(ByVal Adi As String, ByVal ID As String)
            _Adi = Adi
            _ID = ID
        End Sub
    End Class

    <System.Web.Services.WebMethod()> _
    Public Shared Function ListeGetir(ByVal ID As Integer) As System.Collections.Generic.List(Of Dugme)
        Dim Dugmeler As New DataSet1TableAdapters.DugmelerTableAdapter
        Dim Liste As New System.Collections.Generic.List(Of Dugme)
        For Each satir As Data.DataRow In Dugmeler.GetDataBy(ID).Rows
            Liste.Add(New Dugme(satir.Item("Adi"), satir.Item("ID")))
        Next
        Return Liste
    End Function

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            Dim DillerData As New DataSet1TableAdapters.KategorilerTableAdapter
            Diller.DataValueField = "ID"
            Diller.DataTextField = "Kategori"
            Diller.DataSource = DillerData.GetData
            Diller.DataBind()
        End If

    End Sub
End Class