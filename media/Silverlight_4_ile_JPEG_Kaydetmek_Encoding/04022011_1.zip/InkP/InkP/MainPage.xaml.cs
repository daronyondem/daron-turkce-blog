﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.IO;
using System.Windows.Media.Imaging;

namespace InkP
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            InkPresent.MouseLeftButtonDown += new MouseButtonEventHandler(InkPresent_MouseLeftButtonDown);
            InkPresent.MouseMove += new MouseEventHandler(InkPresent_MouseMove);
            InkPresent.MouseLeftButtonUp += new MouseButtonEventHandler(InkPresent_MouseLeftButtonUp);
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
            this.btnKalinKirmizi.Click += new RoutedEventHandler(btnKalinKirmizi_Click);
            this.btnNormal.Click += new RoutedEventHandler(btnNormal_Click);
            btnSave.Click += new RoutedEventHandler(btnSave_Click);
            btnLoad.Click += new RoutedEventHandler(btnLoad_Click);
            btnSaveJPEG.Click += new RoutedEventHandler(btnSaveJPEG_Click);
        }

private static void SaveToFile(WriteableBitmap bitmap, Stream fs)
{
    int width = bitmap.PixelWidth;
    int height = bitmap.PixelHeight;
    int bands = 3;
    byte[][,] raster = new byte[bands][,];

    for (int i = 0; i < bands; i++)
    {
        raster[i] = new byte[width, height];
    }

    for (int row = 0; row < height; row++)
    {
        for (int column = 0; column < width; column++)
        {
            int pixel = bitmap.Pixels[width * row + column];
            raster[0][column, row] = (byte)(pixel >> 16);
            raster[1][column, row] = (byte)(pixel >> 8);
            raster[2][column, row] = (byte)pixel;
        }
    }

    FluxJpeg.Core.ColorModel model = new FluxJpeg.Core.ColorModel { colorspace = FluxJpeg.Core.ColorSpace.RGB };
    FluxJpeg.Core.Image img = new FluxJpeg.Core.Image(model, raster);

    MemoryStream stream = new MemoryStream();
    FluxJpeg.Core.Encoder.JpegEncoder encoder = new FluxJpeg.Core.Encoder.JpegEncoder(img, 100, stream);
    encoder.Encode();

    stream.Seek(0, SeekOrigin.Begin);

    byte[] binaryData = new Byte[stream.Length];
    long bytesRead = stream.Read(binaryData, 0, (int)stream.Length);
    fs.Write(binaryData, 0, binaryData.Length);
}

        void btnSaveJPEG_Click(object sender, RoutedEventArgs e)
        {
            WriteableBitmap bitmap = new WriteableBitmap(InkPresent, null);

            if (bitmap != null)
            {
                SaveFileDialog saveDlg = new SaveFileDialog();
                saveDlg.Filter = "JPEG Files (*.jpeg)|*.jpeg";
                saveDlg.DefaultExt = ".jpeg";

                if ((bool)saveDlg.ShowDialog())
                {
                    using (Stream fs = saveDlg.OpenFile())
                    {
                        SaveToFile(bitmap, fs);
                    }
                }
            }
        }

        void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            string XMLString = "";
            OpenFileDialog loadDlg = new OpenFileDialog();
            loadDlg.Filter = "XML Files (*.xml)|*.xml";
            loadDlg.Multiselect = false;
            loadDlg.ShowDialog();
            if (loadDlg.File != null)
            {
                XMLString += loadDlg.File.OpenText().ReadToEnd();

                InkPresent.Strokes.Clear();
                XDocument XDoc = XDocument.Parse(XMLString);
                System.Windows.Ink.Stroke LoadedStroke;
                StylusPoint LoadedPoint;

                foreach (XElement XStroke in XDoc.Element("Strokes").Elements("Stroke"))
                {
                    LoadedStroke = new System.Windows.Ink.Stroke();
                    LoadedStroke.DrawingAttributes.Height = double.Parse(XStroke.Element("Height").Value);
                    LoadedStroke.DrawingAttributes.Width = double.Parse(XStroke.Element("Width").Value);
                    LoadedStroke.DrawingAttributes.Color = Color.FromArgb(byte.Parse(XStroke.Element("Color").Attribute("A").Value),
                                                                            byte.Parse(XStroke.Element("Color").Attribute("R").Value),
                                                                            byte.Parse(XStroke.Element("Color").Attribute("G").Value),
                                                                            byte.Parse(XStroke.Element("Color").Attribute("B").Value));

                    foreach (XElement XPoint in XStroke.Element("Points").Elements("Point"))
                    {
                        LoadedPoint = new StylusPoint();
                        LoadedPoint.X = double.Parse(XPoint.Attribute("X").Value);
                        LoadedPoint.Y = double.Parse(XPoint.Attribute("Y").Value);
                        LoadedStroke.StylusPoints.Add(LoadedPoint);
                    }
                    InkPresent.Strokes.Add(LoadedStroke);
                }
            }
        }

        void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var xmlElements =
                new XElement("Strokes", InkPresent.Strokes.Select(stroke =>
                        new XElement("Stroke",
                            new XElement("Color",
                                new XAttribute("A", stroke.DrawingAttributes.Color.A),
                                new XAttribute("R", stroke.DrawingAttributes.Color.R),
                                new XAttribute("G", stroke.DrawingAttributes.Color.G),
                                new XAttribute("B", stroke.DrawingAttributes.Color.B)
                            ),
                            new XElement("Points", stroke.StylusPoints
                                .Select(point =>
                                    new XElement("Point",
                                        new XAttribute("X", point.X),
                                        new XAttribute("Y", point.Y)
                                    )
                                )
                            ),
                            new XElement("Width", stroke.DrawingAttributes.Width),
                            new XElement("Height", stroke.DrawingAttributes.Height)
                        )
                    )
                );

            SaveFileDialog saveDlg = new SaveFileDialog();
            saveDlg.Filter = "XML Files (*.xml)|*.xml";
            saveDlg.DefaultExt = ".xml";

            if ((bool)saveDlg.ShowDialog())
            {
                using (Stream fs = saveDlg.OpenFile())
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(fs);
                    sw.WriteLine(xmlElements.ToString());
                    sw.Flush();
                    sw.Close();
                    fs.Close();
                }
            }
        }

        void btnKalinKirmizi_Click(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
            Att.Color = Colors.Red;
            Att.Width = 10;
        }

        void btnNormal_Click(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
            Att.Color = Colors.Black;
            Att.Width = 3;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            Att = new System.Windows.Ink.DrawingAttributes();
        }
                
        System.Windows.Ink.Stroke newStroke;
        System.Windows.Ink.DrawingAttributes Att;

        void InkPresent_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            InkPresent.CaptureMouse();
            newStroke = new System.Windows.Ink.Stroke();
            newStroke.DrawingAttributes = Att;
            newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(InkPresent));
            InkPresent.Strokes.Add(newStroke);
        }

        void InkPresent_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            newStroke = null;
            InkPresent.ReleaseMouseCapture();
        }

        void InkPresent_MouseMove(object sender, MouseEventArgs e)
        {
            if (newStroke != null)
            {
                newStroke.StylusPoints.Add(e.StylusDevice.GetStylusPoints(InkPresent));
            }
        }
    }
}
