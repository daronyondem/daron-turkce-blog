
System.Gadget.onSettingsClosing = settingsClosing;

function settingsClosing(event)
{
    if(event.closeAction == event.Action.commit)
    {
        saveSettings();
    }
    else if (event.closeAction == event.Action.cancel)
    {
    }
}
function saveSettings() {

	var hours = pingfeedhours.options[pingfeedhours.selectedIndex].value;
	System.Gadget.Settings.write("pingfeedhours", hours);
	
	UpdateGadget();
}
function loadSettings() {

	var hoursIndex = 1;
	switch (System.Gadget.Settings.read("pingfeedhours"))
	{
	   case 1:
	      hoursIndex = 0;
	      break;
	   case 4:
	      hoursIndex = 1;
	      break;
	   case 12:
	      hoursIndex = 2;
	      break;
	   case 24:
	      hoursIndex = 3;
	      break;
	}
	pingfeedhours.selectedIndex = hoursIndex;
}
function UpdateGadget() {
    try{
        System.Gadget.document.parentWindow.location.href = System.Gadget.document.parentWindow.location.href;
    } catch(err) {}
} 
