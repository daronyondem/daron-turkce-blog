
var gadgetVer = 1.0;
var rssSource = "http://daron.yondem.com/tr/SyndicationService.asmx/GetRss";


xmlDoc = new ActiveXObject("Msxml2.DOMDocument.3.0");
System.Gadget.settingsUI = "settings.html";

function setup() {

	System.Gadget.onUndock = undocked;
	System.Gadget.onDock = docked;
	
	if (!System.Gadget.Settings.read("grow")) {
		System.Gadget.Settings.write("grow", 1);
	}
	
	if (!System.Gadget.docked) {
		undocked();
	}
	
	getRSS();

	if (!System.Gadget.Settings.read("pingfeedhours")) {
		System.Gadget.Settings.write("pingfeedhours", 5);
	}

	var hours = System.Gadget.Settings.read("pingfeedhours");

	hours = hours * 60 * 60000;  //x hours * y minutes * 60000 miliseconds
	window.setInterval(getRSS, hours);
}

System.Gadget.onSettingsClosed = settingsClosed;

function settingsClosed() {
	if (!System.Gadget.docked) {
		undocked();
	} 
}

function docked() {
	styleUndocked.disabled = true;
	styleDocked.disabled = false;
	System.Gadget.background = "url('images/docked3.png')";
	with (document.body.style) {
		width = 135;
		height = 150;
	}
}

function undocked() {
		docked();
}
////////////////////////////////////////////////////////////////////////////////
//
// XML Functions
////////////////////////////////////////////////////////////////////////////////
function getRSS() {
	loading.innerText = "Baglaniyor...";					
	rssObj = new ActiveXObject("Msxml2.XMLHTTP");
	rssObj.open("GET", rssSource + "?f=" + Math.random(), true); 
	rssObj.onreadystatechange = function() {
		if (rssObj.readyState === 4) {
			if (rssObj.status === 200) {
				loading.innerText = "";
				rssXML = rssObj.responseXML;
				parseRSS();
				if (chkConn) { clearInterval(chkConn); }
			} else {
				var chkConn;
				loading.innerText = "Baglanti yok.";				
				chkConn = setInterval(getRSS, 30000);
			}
    	} else {
			loading.innerText = "Baglaniyor...";
		}
		
	}	
	rssObj.send(null);
}


function parseRSS() {
	

	rssItems = rssXML.getElementsByTagName("item");
	rssTitle = null;  
		rssTitle = rssItems[0].getElementsByTagName("title")[0].text;
		document.getElementById("cell0").innerHTML = '<div  onClick=\"showFlyout(0);\"><div class="title">' + rssTitle + '</div></div>';
					

}