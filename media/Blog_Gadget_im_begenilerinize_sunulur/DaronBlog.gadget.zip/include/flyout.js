
var flyoutFile = "flyout.html";
var timeout = 600000;
var itemCount;
var htmlContent;
var remoteLink;
var content;
var rlink;
var flyoutDiv;
var rssLink;
var oldi;

function flyInit () {
	rssDes = null;
	rssitems = System.Gadget.document.parentWindow.rssItems;
	theItem=System.Gadget.document.parentWindow.itemCount;
	rssTitle = rssitems[theItem].getElementsByTagName("title")[0].text;
	rssDes=rssitems[theItem].getElementsByTagName("description");
	rssDes = rssDes[0].text;
	document.getElementById("flyContent").innerHTML = "<strong>" + rssTitle + "</strong>" + "<br><br>" + rssDes;
	document.body.style.backgroundImage = "url(images/flyout.png)";
	rssLinkArray = rssitems[theItem].getElementsByTagName("link"); 
	rssLink = rssLinkArray[0].text;
	document.getElementById("tipLinkBox").innerHTML = '<div id=\"tipLinkHot\" onclick="System.Shell.execute(\'' + rssLink + '\');">blogda oku</div>';
	
	
}


function showFlyout ( i ) 

{ 

      System.Gadget.Flyout.file = flyoutFile;      
      System.Gadget.Flyout.show = true;
      
    if ( timeout > 0 ) 
         setTimeout( "hideFlyout();", timeout);
            
    if ( window.event != null ) 
    { 
        window.event.cancelBubble = true ; 
        window.event.returnValue = false; 
    }
	itemCount = i;
	if (oldi == i) hideFlyout ();
	oldi=i;
	
	
} 

function hideFlyout () 
{ 
 System.Gadget.Flyout.show = false ;
} 

////////////////////////////////////////////////////////////////
//////  Below code allows for flyout text to be selected
////////////////////////////////////////////////////////////////

var selectionEntry; // stores the position where user clicked 
var selectionRange; // the actual selection which gets highlighted

function StartSelection()
{
 selectionEntry = document.body.createTextRange();
 try { selectionEntry.moveToPoint(event.clientX, event.clientY); }
 catch (invalidPoint) { return; } // for example, inside text box
 
 // since we are going to adjust the range according to user's input
 // we need to keep the entry point in separate variable
 selectionRange = selectionEntry.duplicate();
}

function TrackSelection()
{
 if (event.button == 1) // adjust the selection only on the left button pressed
 {
   var mousePoint = document.body.createTextRange();
   try { mousePoint.moveToPoint(event.clientX, event.clientY); }
   catch (invalidPoint) { return; } 
   
   // we only have a possibility to change either the start point or the end point
   // of the selection range and setting the end one prior the start one does not
   // work, so we need to decide wheter to adjust 'to the left' or 'to the right'
   var start;
   try { start = mousePoint.compareEndPoints('StartToStart', selectionEntry); }
   catch (uncomparablePoints) { return; } // for example you cannot extend paragraph
                                          // selection into the middle of textbox
                                          
   if (start == -1) // cursor is far left than it was when it was at mouse down event
                    // if we were comparing to the selectionRange directly, the cursor
                    // would fall to the other case immediately after adjustment,
                    // resulting in collapse of the range to the start point
                    // (so one could select only to the right/down direction)
    selectionRange.setEndPoint('StartToStart', mousePoint);
   else
    selectionRange.setEndPoint('EndToStart', mousePoint);
   
   selectionRange.select(); // highlights the range
 } 
}

