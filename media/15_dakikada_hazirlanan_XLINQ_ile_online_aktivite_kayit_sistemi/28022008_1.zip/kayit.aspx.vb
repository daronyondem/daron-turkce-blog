﻿
Partial Class kayit
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If String.IsNullOrEmpty(Request.QueryString("tag")) = False Then
            Dim Belge = XDocument.Load(Server.MapPath("App_Data") & "\" & Request.QueryString("tag") & ".xml")
            Belge.<Olay>.<Tag>.Value = TextBox2.Text
            Belge.<Olay>.<Katilimci>.Value = TextBox3.Text
            Belge.<Olay>.<Icerik>.Value = TextBox1.Text
            Belge.Save(Server.MapPath("App_Data") & "\" & TextBox2.Text & ".xml")
            If Request.QueryString("tag") <> TextBox2.Text Then
                IO.File.Delete(Server.MapPath("App_Data") & "\" & Request.QueryString("tag") & ".xml")
            End If
        Else
            Dim Belge As New XDocument
            Dim root As New XElement("Olay")
            root.Add(New XElement("Tag", TextBox2.Text))
            root.Add(New XElement("Icerik", TextBox1.Text))
            root.Add(New XElement("Katilimci", TextBox3.Text))
            Belge.Add(root)
            Belge.Save(Server.MapPath("App_Data") & "\" & TextBox2.Text & ".xml")
        End If

        Response.Redirect("kayitlar.aspx")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Login") <> True Then Response.Redirect("login.aspx")

        If Page.IsPostBack = False Then
            If String.IsNullOrEmpty(Request.QueryString("tag")) = False Then
                Dim Belge = XDocument.Load(Server.MapPath("App_Data") & "\" & Request.QueryString("tag") & ".xml")
                TextBox2.Text = Belge.<Olay>.<Tag>.Value
                TextBox3.Text = Belge.<Olay>.<Katilimci>.Value
                TextBox1.Text = Belge.<Olay>.<Icerik>.Value

                GridView1.DataSource = From Gelenler In Belge.<Olay>.<Katilan> Select Gelenler.@Adi, Gelenler.@Mail, Gelenler.@Tel
                GridView1.DataBind()
            End If
        End If

    End Sub
End Class
