﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Tamam") = True Then
            kayittablo.Visible = False
            Label1.Text = "Teşekkürler"
        End If
        If Page.IsPostBack = False Then
            If String.IsNullOrEmpty(Request.QueryString("event")) = False Then
                Try
                    Dim Belge = XDocument.Load(Server.MapPath("App_Data") & "\" & Request.QueryString("event") & ".xml")
                    If Belge.<Olay>.<Katilimci>.Value <= Belge.<Olay>.<Katilan>.Count And Belge.<Olay>.<Katilimci>.Value <> 0 Then
                        Label1.Text = "Aktivite için maksimum kayıt sayısına ulaşıldı. Üzgünüz, bir dahakine."
                        kayittablo.Visible = False
                    Else
                        Label1.Text = Belge.<Olay>.<Icerik>.Value
                    End If

                Catch ex As Exception
                    Label1.Text = "Yok böyle birşey"
                    kayittablo.Visible = False
                End Try


                'TextBox2.Text = Belge.<Olay>.<Tag>.Value
                'TextBox3.Text = Belge.<Olay>.<Katilimci>.Value
                'TextBox1.Text = Belge.<Olay>.<Icerik>.Value
            Else
                Label1.Text = "Yok böyle birşey"
                kayittablo.Visible = False
            End If
        End If
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Session("Tamam") <> True Then
            Dim Belge = XDocument.Load(Server.MapPath("App_Data") & "\" & Request.QueryString("event") & ".xml")
            Belge.<Olay>.SingleOrDefault.Add(New XElement("Katilan", New XAttribute("Adi", TextBox1.Text), New XAttribute("Mail", TextBox2.Text), New XAttribute("Tel", TextBox3.Text)))
            Belge.Save(Server.MapPath("App_Data") & "\" & Request.QueryString("event") & ".xml")
            kayittablo.Visible = False
            Label1.Text = "Teşekkürler"
            Session("Tamam") = True
        End If


    End Sub
End Class
