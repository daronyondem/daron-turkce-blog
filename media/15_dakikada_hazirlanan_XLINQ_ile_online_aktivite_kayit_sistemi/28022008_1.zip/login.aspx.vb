﻿
Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "HebeleGubele" Then
            Session("Login") = True
            Response.Redirect("kayitlar.aspx")
        End If
    End Sub
End Class
