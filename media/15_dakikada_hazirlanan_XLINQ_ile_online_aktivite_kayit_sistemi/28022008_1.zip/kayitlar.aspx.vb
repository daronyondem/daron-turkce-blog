﻿
Partial Class kayitlar
    Inherits System.Web.UI.Page

    Sub VeriGetir()
        Dim Dosyalar = IO.Directory.GetFiles(Server.MapPath("App_Data"))
        Dim tablo As New Data.DataTable("Gelenler")
        tablo.Columns.Add(New Data.DataColumn("Tag"))
        Dim satir As Data.DataRow
        For Each dosya In Dosyalar
            satir = tablo.NewRow
            satir.Item("Tag") = System.IO.Path.GetFileNameWithoutExtension(dosya)
            tablo.Rows.Add(satir)
        Next

        GridView1.DataSource = tablo
        GridView1.DataBind()
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("Login") <> True Then Response.Redirect("login.aspx")
        If Page.IsPostBack = False Then
            VeriGetir()
        End If

    End Sub

    Protected Sub GridView1_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridView1.RowDeleting

        System.IO.File.Delete(Server.MapPath("App_Data") & "\" & GridView1.DataKeys(e.RowIndex).Value & ".xml")
        VeriGetir()
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("kayit.aspx")

    End Sub
End Class
